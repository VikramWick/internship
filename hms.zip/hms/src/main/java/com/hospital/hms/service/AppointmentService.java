package com.hospital.hms.service;



import com.hospital.hms.dto.AppointmentRequest;
import com.hospital.hms.model.*;
import com.hospital.hms.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    public Optional<Appointment> getAppointmentById(Long id) {
        return appointmentRepository.findById(id);
    }

    public List<Appointment> getAppointmentsByPatientId(Long patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    public List<Appointment> getAppointmentsByDoctorId(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    public Appointment createAppointment(AppointmentRequest request) {
        // Find the doctor by name and speciality
        Doctor doctor = doctorRepository.findByNameAndSpecialist(request.getDoctor().getName(), request.getDoctor().getSpecialist())
                .orElseThrow(() -> new RuntimeException("Doctor not found with name: " + request.getDoctor().getName() +
                        " and specialist: " + request.getDoctor().getSpecialist()));

        // Create the appointment
        Appointment appointment = new Appointment();
        appointment.setPatient(request.getPatient()); // Full patient details
        appointment.setDoctor(doctor);
        appointment.setAppointmentDate(request.getAppointmentDate());
        appointment.setStatus(request.getStatus());
        appointment.setNotes(request.getNotes());

        return appointmentRepository.save(appointment);
    }


    public Appointment updateAppointment(Long id, Appointment updatedAppointment) {
        return appointmentRepository.findById(id).map(appointment -> {
            appointment.setAppointmentDate(updatedAppointment.getAppointmentDate());
            appointment.setStatus(updatedAppointment.getStatus());
            appointment.setNotes(updatedAppointment.getNotes());
            return appointmentRepository.save(appointment);
        }).orElseThrow(() -> new RuntimeException("Appointment not found with id: " + id));
    }

    public void deleteAppointment(Long id) {
        appointmentRepository.deleteById(id);
    }
}
