package com.hospital.hms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hospital.hms.repository.*;
import java.util.List;
import com.hospital.hms.model.Patient;
import com.hospital.hms.exception.*;





@RestController
@RequestMapping("/api/v1")
public class PatientController {

    @Autowired
    private PatientRepository patientRepository;

    
	@GetMapping("/patients-info")
	public List<Patient>getAllEmployees(){
		return patientRepository.findAll();
		
	}
    
	@PostMapping("/patients-info")
	public Patient createPatient(@RequestBody Patient patient) {
        return patientRepository.save(patient);		
	}
	
	
	@GetMapping("/patients-info/{id}")
	public ResponseEntity<Patient> getDoctorById(@PathVariable Long id){
		Patient patient = patientRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Doctor not exist with ID :" + id));
	 return ResponseEntity.ok(patient);
    }



    
}
