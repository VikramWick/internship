package com.hospital.hms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDate;

import jakarta.persistence.*;

@Entity
@Table(name = "Patients_Info")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "patient_id")
    private long id;

    @Column(name = "Name")
    private String name;

    @Column(name = "Age")
    private int age;


    @Column(name = "Gender")
    private String gender;

    
    @Column(name = "Address")
    private String address;

    @Column(name = "ContactNo")
    private String contactNo;


    @Column(name = "VisitedDoctor")
    private String visitedDoctor;

    @Column(name = "DateOfVisit")
    private LocalDate dateOfVisit;

    

   
    public Patient() {
    }

    public Patient(String name, String visitedDoctor, LocalDate dateOfVisit, String gender, int age, String address, String contactNo) {
        super();
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.address = address;
        this.contactNo = contactNo;
        this.visitedDoctor = visitedDoctor;
        this.dateOfVisit = dateOfVisit;
        
        
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVisitedDoctor() {
        return visitedDoctor;
    }

    public void setVisitedDoctor(String visitedDoctor) {
        this.visitedDoctor = visitedDoctor;
    }

    public LocalDate getDateOfVisit() {
        return dateOfVisit;
    }

    public void setDateOfVisit(LocalDate dateOfVisit) {
        this.dateOfVisit = dateOfVisit;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }
}